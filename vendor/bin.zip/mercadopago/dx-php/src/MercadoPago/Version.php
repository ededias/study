<?php
namespace MercadoPago;

class Version
{
    public static
        $_VERSION = '1.8.0';
}
